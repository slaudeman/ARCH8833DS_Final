require('es6-promise').polyfill();
require('isomorphic-fetch');

var prompt = require('prompt');

var maxId = Number.MAX_SAFE_INTEGER
var minId = 6;
var newId = Math.floor(Math.random() * (maxId - minId + 1)) + minId
var id
var name
var lineweight
var clr


 
  //
  // Start the prompt
  //
  prompt.start();
 
  //
  // Get properties from user - still using random safe seed.
  //
  prompt.get(['name', 'clr','lineweight'], function (err, result) {
    //
    // Log the results.
    //
    console.log('Command-line input received:');
    console.log('  name: ' + result.name);
    console.log('  color: ' + result.clr);
	console.log('  lineweight: ' + result.clr);
	
	name = result.name;
	lineweight = result.lineweight;
	clr = result.clr;
	
fetch('http://localhost:8000/spaces/', {
  method: 'post',
  headers: {
    'Accept': 'application/json',
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({
       "id": newId, 
	   "name": name,
	   "clr": clr,
	   "lineweight": lineweight
   })
}).then(function(response) {
      return response.json()
    }).then(function(json) {
      console.log('parsed json: ', json)
    }).catch(function(ex) {
      console.log('parsing failed: ', ex)
    });

  });

